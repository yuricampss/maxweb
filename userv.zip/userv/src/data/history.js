export const historyFromPartner = [
    {
        id: 1,
        date: '2024-01-14',
        client: 'João pedro',
        service: 'Ajustes',
        price: 100.50,
        status: true
    },
    {
        id: 2,
        date: '2024-01-14',
        client: 'Rafael',
        service: 'Reparos',
        price: 300,
        status: true
    },
    {
        id: 3,
        date: '2024-01-14',
        client: 'Ana Carolina',
        service: 'Pintura',
        price: 250,
        status: true
    },
    {
        id: 4,
        date: '2024-01-14',
        client: 'Thiago',
        service: 'Consultoria',
        price: 800,
        status: false
    },
    {
        id: 5,
        date: '2024-01-14',
        client: 'Fernanda',
        service: 'desenho',
        price: 445,
        status: true
    },
    {
        id: 6,
        date: '2024-01-14',
        client: 'Michel',
        service: 'ajustes',
        price: 200,
        status: false
    },
    {
        id: 7,
        date: '2024-01-14',
        client: 'Tatiana',
        service: 'Gastronomia',
        price: 45,
        status: true
    },
    {
        id: 8,
        date: '2024-01-14',
        client: 'Jose',
        service: 'Construção',
        price: 260,
        status: true
    }
]
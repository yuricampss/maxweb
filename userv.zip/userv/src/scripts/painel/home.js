import { handleParceiroHeader, partnerRouteProtection } from "../render.js";

partnerRouteProtection('closed');
handleParceiroHeader();